import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  ClipboardList,
  Clock3,
  Download,
  Eye,
  EyeOff,
  KeyRound,
  Lock,
  LogOut,
  Mail,
  Plus,
  Search,
  ShieldCheck,
  UserCheck,
  UserPlus,
  Users,
} from "lucide-react";

function Card({ className = "", children }) {
  return <div className={`border bg-white ${className}`}>{children}</div>;
}

function CardContent({ className = "", children }) {
  return <div className={className}>{children}</div>;
}

function Button({ className = "", variant = "default", children, ...props }) {
  const base = "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition disabled:pointer-events-none disabled:opacity-50";
  const styles =
    variant === "outline"
      ? "border border-slate-200 bg-white text-slate-900 hover:bg-slate-50"
      : "bg-slate-900 text-white hover:bg-slate-800";
  return (
    <button className={`${base} ${styles} ${className}`} {...props}>
      {children}
    </button>
  );
}

const defaultUsers = [
  { id: "U001", name: "Pradeep", loginId: "pradeep.accounts", officeId: "pradeep@office.com", password: "Pradeep@123", role: "Admin / Team Leader", department: "Accounts", canAddMember: true },
  { id: "U002", name: "Abhishek", loginId: "abhishek.accounts", officeId: "abhishek@office.com", password: "Abhishek@123", role: "Team Member", department: "Accounts", canAddMember: false },
  { id: "U003", name: "Mounika", loginId: "mounika.accounts", officeId: "mounika@office.com", password: "Mounika@123", role: "Team Member", department: "Accounts", canAddMember: false },
  { id: "U004", name: "Swathi V", loginId: "swathiv.accounts", officeId: "swathiv@office.com", password: "SwathiV@123", role: "Team Member", department: "Accounts", canAddMember: false },
  { id: "U005", name: "M Swathi", loginId: "mswathi.accounts", officeId: "mswathi@office.com", password: "MSwathi@123", role: "Team Member", department: "Accounts", canAddMember: false },
  { id: "U006", name: "Shashi", loginId: "shashi.accounts", officeId: "shashi@office.com", password: "Shashi@123", role: "Team Member", department: "Accounts", canAddMember: false },
  { id: "U007", name: "Modi ji", loginId: "modiji.accounts", officeId: "modiji@office.com", password: "Modiji@123", role: "Team Member", department: "Accounts", canAddMember: false },
  { id: "U008", name: "Ashutosh Singh", loginId: "ashutosh.accounts", officeId: "ashutosh@office.com", password: "Ashutosh@123", role: "Team Member", department: "Accounts", canAddMember: false },
];

const initialTasks = [];

const developerTestCases = [
  "Admin / Team Leader should see every active task.",
  "Team member should see tasks assigned to them, created by them, or where they are mentioned.",
  "Unrelated team member should not see other members' tasks.",
  "Assigned person and Leader can update status to Completed.",
  "Task creator can see the task but cannot complete it unless they are also assigned or Leader.",
  "Completed task should move to history immediately.",
  "Completed task should remain in history for 30 days only.",
  "Forgot password should require Office ID, code, and matching new passwords.",
  "CSV export should include only visible tasks for the current view.",
  "Assign To and Mentions dropdowns must render all users and close JSX braces correctly.",
];

function statusClass(status) {
  if (status === "Completed") return "bg-emerald-100 text-emerald-700 border-emerald-200";
  if (status === "In Progress") return "bg-blue-100 text-blue-700 border-blue-200";
  return "bg-amber-100 text-amber-700 border-amber-200";
}

function priorityClass(priority) {
  if (priority === "High") return "bg-red-100 text-red-700";
  if (priority === "Medium") return "bg-purple-100 text-purple-700";
  return "bg-slate-100 text-slate-700";
}

function dateLabel(date) {
  if (!date) return "-";
  return new Date(date).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "2-digit",
  });
}

function buildCsv(tasks) {
  const headers = [
    "Task ID",
    "Task Description",
    "Assigned By",
    "Assigned To",
    "Department/Customer",
    "Behalf Of",
    "Assigned Date",
    "Target Date",
    "Priority",
    "Current Status",
  ];

  const rows = tasks.map((task) => [
    task.id,
    task.title,
    task.assignedBy,
    task.assignedTo,
    task.department,
    task.behalfOf,
    task.assignedDate,
    task.targetDate,
    task.priority,
    task.status,
  ]);

  return [headers, ...rows]
    .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","))
    .join("\n");
}

function exportCSV(tasks) {
  const csv = buildCsv(tasks);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "office_task_tracker.csv";
  link.click();
  URL.revokeObjectURL(url);
}

function isTaskVisibleToUser(task, user) {
  if (!user) return false;
  if (user.canAddMember) return true;
  const mentionedUsers = Array.isArray(task.mentions) ? task.mentions : [];
  return task.assignedTo === user.name || task.assignedBy === user.name || mentionedUsers.includes(user.name);
}

function canUpdateTaskStatus(task, user) {
  if (!user) return false;
  return user.canAddMember || task.assignedTo === user.name;
}

function isCompletedTaskWithinHistory(task, today = new Date()) {
  if (task.status !== "Completed" || !task.completedDate) return false;
  const completedDate = new Date(task.completedDate);
  const daysAfterCompletion = Math.floor((today.getTime() - completedDate.getTime()) / (1000 * 60 * 60 * 24));
  return daysAfterCompletion <= 30;
}

export default function TaskTrackingDashboard() {
  const [users, setUsers] = useState(defaultUsers);
  const [currentUser, setCurrentUser] = useState(null);
  const [loginId, setLoginId] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [assigneeFilter, setAssigneeFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [tasks, setTasks] = useState(initialTasks);
  const [newMember, setNewMember] = useState({ name: "", loginId: "", officeId: "", password: "", role: "Team Member" });
  const [newTask, setNewTask] = useState({ title: "", description: "", assignedTo: "", behalfOf: "", targetDate: "", priority: "Medium", mentions: [] });
  const [showAssignTask, setShowAssignTask] = useState(true);
  const [taskMessage, setTaskMessage] = useState("");
  const [passwordForm, setPasswordForm] = useState({ oldPassword: "", newPassword: "", confirmPassword: "" });
  const [passwordMessage, setPasswordMessage] = useState("");
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [forgotMode, setForgotMode] = useState(false);
  const [forgotStep, setForgotStep] = useState("email");
  const [forgotForm, setForgotForm] = useState({ officeId: "", code: "", newPassword: "", confirmPassword: "" });
  const [resetCode, setResetCode] = useState("");
  const [forgotMessage, setForgotMessage] = useState("");

  const isLeader = currentUser?.canAddMember === true;

  function handleLogin(event) {
    event.preventDefault();
    const matchedUser = users.find((user) => user.loginId === loginId.trim() && user.password === password.trim());
    if (!matchedUser) {
      setLoginError("Invalid Login ID or Password");
      return;
    }
    setCurrentUser(matchedUser);
    setLoginError("");
  }

  function handleLogout() {
    setCurrentUser(null);
    setStatusFilter("All");
    setAssigneeFilter("All");
    setSearch("");
    setPasswordForm({ oldPassword: "", newPassword: "", confirmPassword: "" });
    setPasswordMessage("");
    setTaskMessage("");
  }

  function changeOwnPassword(event) {
    event.preventDefault();
    setPasswordMessage("");

    if (passwordForm.oldPassword !== currentUser.password) {
      setPasswordMessage("Old password is incorrect.");
      return;
    }
    if (passwordForm.newPassword.length < 8) {
      setPasswordMessage("New password must be at least 8 characters.");
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      setPasswordMessage("New password and confirm password do not match.");
      return;
    }

    setUsers((current) => current.map((user) => (user.id === currentUser.id ? { ...user, password: passwordForm.newPassword } : user)));
    setCurrentUser((user) => ({ ...user, password: passwordForm.newPassword }));
    setPassword(passwordForm.newPassword);
    setPasswordForm({ oldPassword: "", newPassword: "", confirmPassword: "" });
    setPasswordMessage("Password changed successfully.");
  }

  function sendResetCode(event) {
    event.preventDefault();
    const matchedUser = users.find((user) => user.officeId.toLowerCase() === forgotForm.officeId.trim().toLowerCase());
    if (!matchedUser) {
      setForgotMessage("Office ID not found.");
      return;
    }
    const code = String(Math.floor(100000 + Math.random() * 900000));
    setResetCode(code);
    setForgotStep("code");
    setForgotMessage(`Demo reset code sent to ${matchedUser.officeId}: ${code}`);
  }

  function resetPasswordWithCode(event) {
    event.preventDefault();
    if (forgotForm.code !== resetCode) {
      setForgotMessage("Invalid reset code.");
      return;
    }
    if (forgotForm.newPassword.length < 8) {
      setForgotMessage("New password must be at least 8 characters.");
      return;
    }
    if (forgotForm.newPassword !== forgotForm.confirmPassword) {
      setForgotMessage("New password and confirm password do not match.");
      return;
    }

    setUsers((current) =>
      current.map((user) =>
        user.officeId.toLowerCase() === forgotForm.officeId.trim().toLowerCase() ? { ...user, password: forgotForm.newPassword } : user
      )
    );
    setPassword(forgotForm.newPassword);
    setForgotMessage("Password reset successfully. Please login with your new password.");
    setForgotMode(false);
    setForgotStep("email");
    setForgotForm({ officeId: "", code: "", newPassword: "", confirmPassword: "" });
    setResetCode("");
  }

  function addNewMember(event) {
    event.preventDefault();
    if (!newMember.name.trim() || !newMember.loginId.trim() || !newMember.officeId.trim() || !newMember.password.trim()) return;

    const isDuplicateLogin = users.some((user) => user.loginId.toLowerCase() === newMember.loginId.trim().toLowerCase());
    const isDuplicateOfficeId = users.some((user) => user.officeId.toLowerCase() === newMember.officeId.trim().toLowerCase());
    if (isDuplicateLogin || isDuplicateOfficeId) return;

    const nextId = `U${String(users.length + 1).padStart(3, "0")}`;
    setUsers((current) => [
      ...current,
      {
        id: nextId,
        name: newMember.name.trim(),
        loginId: newMember.loginId.trim(),
        officeId: newMember.officeId.trim(),
        password: newMember.password.trim(),
        role: "Team Member",
        department: "Accounts",
        canAddMember: false,
      },
    ]);
    setNewMember({ name: "", loginId: "", officeId: "", password: "", role: "Team Member" });
  }

  const activeTasks = useMemo(() => tasks.filter((task) => task.status !== "Completed"), [tasks]);

  const historyTasks = useMemo(() => {
    const today = new Date();
    return tasks.filter((task) => isCompletedTaskWithinHistory(task, today));
  }, [tasks]);

  const visibleTasks = useMemo(() => {
    if (!currentUser) return [];
    return activeTasks.filter((task) => {
      const userAllowed = isTaskVisibleToUser(task, currentUser);
      const statusAllowed = statusFilter === "All" || task.status === statusFilter;
      const assigneeAllowed = assigneeFilter === "All" || task.assignedTo === assigneeFilter;
      const searchText = `${task.id} ${task.title} ${task.description} ${task.assignedBy} ${task.assignedTo} ${task.behalfOf} ${task.department}`.toLowerCase();
      return userAllowed && statusAllowed && assigneeAllowed && searchText.includes(search.toLowerCase());
    });
  }, [activeTasks, currentUser, statusFilter, assigneeFilter, search]);

  const visibleHistoryTasks = useMemo(() => {
    if (!currentUser) return [];
    return historyTasks.filter((task) => {
      const userAllowed = isTaskVisibleToUser(task, currentUser);
      const assigneeAllowed = assigneeFilter === "All" || task.assignedTo === assigneeFilter;
      const searchText = `${task.id} ${task.title} ${task.description} ${task.assignedBy} ${task.assignedTo} ${task.behalfOf} ${task.department}`.toLowerCase();
      return userAllowed && assigneeAllowed && searchText.includes(search.toLowerCase());
    });
  }, [historyTasks, currentUser, assigneeFilter, search]);

  const summary = useMemo(() => {
    const total = visibleTasks.length;
    const pending = visibleTasks.filter((task) => task.status === "Pending").length;
    const progress = visibleTasks.filter((task) => task.status === "In Progress").length;
    const completed = visibleHistoryTasks.length;
    return { total, pending, progress, completed };
  }, [visibleTasks, visibleHistoryTasks]);

  const behalfSummary = useMemo(() => {
    const map = {};
    visibleTasks.forEach((task) => {
      map[task.behalfOf] = (map[task.behalfOf] || 0) + 1;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [visibleTasks]);

  function createTask(event) {
    event.preventDefault();
    setTaskMessage("");

    if (!newTask.title.trim() || !newTask.assignedTo || !newTask.targetDate) {
      setTaskMessage("Please enter task title, assign-to person, and target date.");
      return;
    }

    const nextTaskId = `TASK-${String(tasks.length + 1).padStart(4, "0")}`;
    const today = new Date().toISOString().slice(0, 10);

    setTasks((current) => [
      ...current,
      {
        id: nextTaskId,
        title: newTask.title.trim(),
        description: newTask.description.trim(),
        assignedBy: currentUser.name,
        assignedTo: newTask.assignedTo,
        behalfOf: newTask.behalfOf.trim() || currentUser.name,
        department: "Accounts",
        assignedDate: today,
        targetDate: newTask.targetDate,
        priority: newTask.priority,
        status: "Pending",
        completedDate: "",
        mentions: newTask.mentions,
      },
    ]);

    setNewTask({ title: "", description: "", assignedTo: "", behalfOf: "", targetDate: "", priority: "Medium", mentions: [] });
    setTaskMessage("Task assigned successfully. It is now visible to the assigned person, creator, mentioned users, and leader.");
  }

  function updateTaskStatus(taskId, newStatus) {
    const today = new Date().toISOString().slice(0, 10);
    setTasks((current) =>
      current.map((task) =>
        task.id === taskId
          ? {
              ...task,
              status: newStatus,
              completedDate: newStatus === "Completed" ? today : "",
            }
          : task
      )
    );
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 p-4 text-white md:p-8">
        <div className="mx-auto grid min-h-[calc(100vh-64px)] max-w-6xl items-center gap-8 lg:grid-cols-2">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
            <p className="mb-3 inline-flex rounded-full bg-blue-500/10 px-4 py-2 text-sm font-semibold text-blue-300">Internal Task Tracking System</p>
            <h1 className="text-4xl font-bold tracking-tight md:text-5xl">Secure Login Dashboard</h1>
            <p className="mt-4 max-w-xl text-slate-300">
              Har employee ka individual Login ID aur Password hoga. Any team member task assign kar sakta hai. Leader sabka pending, in-progress aur history data dekh sakta hai.
            </p>
            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              <div className="rounded-3xl bg-white/10 p-4">
                <ShieldCheck className="mb-2 h-6 w-6 text-emerald-300" />
                <p className="font-semibold">Leader Control</p>
                <p className="text-xs text-slate-300">Leader can see all tasks</p>
              </div>
              <div className="rounded-3xl bg-white/10 p-4">
                <Lock className="mb-2 h-6 w-6 text-amber-300" />
                <p className="font-semibold">Private Login</p>
                <p className="text-xs text-slate-300">Individual ID and password</p>
              </div>
              <div className="rounded-3xl bg-white/10 p-4">
                <ClipboardList className="mb-2 h-6 w-6 text-blue-300" />
                <p className="font-semibold">Mobile Ready</p>
                <p className="text-xs text-slate-300">Task cards for mobile</p>
              </div>
            </div>
          </motion.div>

          <Card className="rounded-3xl border-0 bg-white text-slate-900 shadow-2xl">
            <CardContent className="p-6 md:p-8">
              <div className="mb-6">
                <h2 className="text-2xl font-bold">Login</h2>
                <p className="text-sm text-slate-500">Use your official Accounts task login.</p>
              </div>
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="text-sm font-semibold text-slate-600">Login ID</label>
                  <input value={loginId} onChange={(event) => setLoginId(event.target.value)} className="mt-1 w-full rounded-2xl border p-3 outline-none focus:border-blue-500" placeholder="example.accounts" />
                </div>
                <div>
                  <label className="text-sm font-semibold text-slate-600">Password</label>
                  <div className="mt-1 flex items-center rounded-2xl border pr-3 focus-within:border-blue-500">
                    <input type={showPassword ? "text" : "password"} value={password} onChange={(event) => setPassword(event.target.value)} className="w-full rounded-2xl p-3 outline-none" placeholder="Enter password" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="text-slate-500">
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                </div>
                {loginError && <p className="rounded-2xl bg-red-50 p-3 text-sm font-semibold text-red-700">{loginError}</p>}
                <Button type="submit" className="w-full rounded-2xl py-6 text-base">Login to Dashboard</Button>
              </form>

              <button type="button" onClick={() => { setForgotMode(!forgotMode); setForgotMessage(""); }} className="mt-4 text-sm font-semibold text-blue-700">
                Forgot Password?
              </button>

              {forgotMode && (
                <div className="mt-4 rounded-2xl border bg-slate-50 p-4">
                  <div className="mb-3 flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    <p className="font-bold">Reset password using Office ID</p>
                  </div>
                  {forgotStep === "email" ? (
                    <form onSubmit={sendResetCode} className="space-y-3">
                      <input value={forgotForm.officeId} onChange={(event) => setForgotForm({ ...forgotForm, officeId: event.target.value })} placeholder="Enter office email ID" className="w-full rounded-2xl border bg-white p-3 outline-none" />
                      <Button type="submit" className="w-full rounded-2xl">Send Code</Button>
                    </form>
                  ) : (
                    <form onSubmit={resetPasswordWithCode} className="space-y-3">
                      <input value={forgotForm.code} onChange={(event) => setForgotForm({ ...forgotForm, code: event.target.value })} placeholder="Enter 6-digit code" className="w-full rounded-2xl border bg-white p-3 outline-none" />
                      <input type="password" value={forgotForm.newPassword} onChange={(event) => setForgotForm({ ...forgotForm, newPassword: event.target.value })} placeholder="New password" className="w-full rounded-2xl border bg-white p-3 outline-none" />
                      <input type="password" value={forgotForm.confirmPassword} onChange={(event) => setForgotForm({ ...forgotForm, confirmPassword: event.target.value })} placeholder="Confirm new password" className="w-full rounded-2xl border bg-white p-3 outline-none" />
                      <Button type="submit" className="w-full rounded-2xl">Change Password</Button>
                    </form>
                  )}
                  {forgotMessage && <p className="mt-3 rounded-xl bg-white p-3 text-xs font-semibold text-slate-700">{forgotMessage}</p>}
                </div>
              )}

              <div className="mt-6 rounded-2xl bg-slate-50 p-4">
                <p className="text-sm font-bold">Login details are private</p>
                <p className="mt-1 text-xs text-slate-500">Password login screen par show nahi hoga. Login ID aur password Admin / Team Leader se milega.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-4 text-slate-900 md:p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm font-semibold text-blue-700">Internal Task Tracking System</p>
            <h1 className="text-3xl font-bold tracking-tight md:text-4xl">{isLeader ? "Leader Control Dashboard" : "My Task Dashboard"}</h1>
            <p className="mt-2 max-w-3xl text-slate-600">
              {isLeader
                ? "Leader view: all team tasks, member control, reports, pending work, and 30-day history access."
                : "Member view: tasks assigned to you, created by you, or where you are mentioned."}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {isLeader && (
              <Button onClick={() => exportCSV(visibleTasks)} className="rounded-2xl shadow-sm">
                <Download className="mr-2 h-4 w-4" /> Team Report CSV
              </Button>
            )}
            <Button type="button" onClick={() => setShowAssignTask(!showAssignTask)} variant="outline" className="rounded-2xl bg-white shadow-sm">
              <Plus className="mr-2 h-4 w-4" /> {showAssignTask ? "Hide Task Form" : "Assign Task"}
            </Button>
            <Button onClick={handleLogout} variant="outline" className="rounded-2xl bg-white shadow-sm">
              <LogOut className="mr-2 h-4 w-4" /> Logout
            </Button>
          </div>
        </div>

        {isLeader ? (
          <Card className="rounded-3xl border-0 bg-slate-900 text-white shadow-sm">
            <CardContent className="grid gap-4 p-5 md:grid-cols-4">
              <div>
                <p className="text-xs font-semibold text-slate-300">Leader Access</p>
                <p className="text-lg font-bold">{currentUser.name}</p>
                <p className="text-xs text-slate-400">Full team monitoring enabled</p>
              </div>
              <div className="rounded-2xl bg-white/10 p-4">
                <p className="text-xs text-slate-300">Team Members</p>
                <p className="text-2xl font-bold">{users.length}</p>
              </div>
              <div className="rounded-2xl bg-white/10 p-4">
                <p className="text-xs text-slate-300">Admin Rights</p>
                <p className="text-sm font-bold">Add Member + Reports</p>
              </div>
              <div className="rounded-2xl bg-white/10 p-4">
                <p className="text-xs text-slate-300">Visibility</p>
                <p className="text-sm font-bold">All Team Tasks</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="rounded-3xl border-0 bg-blue-50 shadow-sm">
            <CardContent className="grid gap-4 p-5 md:grid-cols-3">
              <div>
                <p className="text-xs font-semibold text-blue-700">Member Access</p>
                <p className="text-lg font-bold text-slate-900">{currentUser.name}</p>
                <p className="text-xs text-slate-600">Personal task view</p>
              </div>
              <div className="rounded-2xl bg-white p-4">
                <p className="text-xs text-slate-500">Your Role</p>
                <p className="text-sm font-bold text-slate-900">Team Member</p>
              </div>
              <div className="rounded-2xl bg-white p-4">
                <p className="text-xs text-slate-500">Visibility</p>
                <p className="text-sm font-bold text-slate-900">Assigned / Created / Mentioned</p>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="rounded-3xl border-0 shadow-sm">
          <CardContent className={`grid gap-4 p-4 ${isLeader ? "md:grid-cols-4" : "md:grid-cols-3"}`}>
            <div className="rounded-2xl bg-slate-50 p-3">
              <p className="text-xs font-semibold text-slate-500">Current Login</p>
              <p className="font-bold">{currentUser.name}</p>
              <p className="text-xs text-slate-500">{currentUser.role}</p>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-500">Status</label>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} className="mt-1 w-full rounded-2xl border bg-white p-3 outline-none">
                <option>All</option>
                <option>Pending</option>
                <option>In Progress</option>
              </select>
            </div>
            {isLeader && (
              <div>
                <label className="text-xs font-semibold text-slate-500">Assigned To</label>
                <select value={assigneeFilter} onChange={(event) => setAssigneeFilter(event.target.value)} className="mt-1 w-full rounded-2xl border bg-white p-3 outline-none">
                  <option>All</option>
                  {users.map((user) => (
                    <option key={user.id} value={user.name}>{user.name}</option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label className="text-xs font-semibold text-slate-500">Search</label>
              <div className="mt-1 flex items-center rounded-2xl border bg-white px-3">
                <Search className="h-4 w-4 text-slate-400" />
                <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Task, user, customer..." className="w-full bg-transparent p-3 outline-none" />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4 md:grid-cols-4">
          {[
            { title: "Active Tasks", value: summary.total, icon: ClipboardList },
            { title: "Pending", value: summary.pending, icon: Clock3 },
            { title: "In Progress", value: summary.progress, icon: BarChart3 },
            { title: "History", value: summary.completed, icon: CheckCircle2 },
          ].map((item, index) => (
            <motion.div key={item.title} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }}>
              <Card className="rounded-3xl border-0 shadow-sm">
                <CardContent className="flex items-center justify-between p-5">
                  <div>
                    <p className="text-sm text-slate-500">{item.title}</p>
                    <p className="mt-1 text-3xl font-bold">{item.value}</p>
                  </div>
                  <div className="rounded-2xl bg-slate-100 p-3"><item.icon className="h-6 w-6" /></div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {showAssignTask && (
          <Card className="rounded-3xl border-0 border-l-4 border-l-blue-600 shadow-sm">
            <CardContent className="p-5">
              <div className="mb-4 flex items-center gap-2">
                <Plus className="h-5 w-5" />
                <div>
                  <h2 className="text-xl font-bold">Assign Task to Internal Team</h2>
                  <p className="text-sm text-slate-500">Any team member can assign a task to another team member or leader. Leader can see all tasks. Assigned person and Leader can complete the task.</p>
                </div>
              </div>
              <form onSubmit={createTask} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                <input value={newTask.title} onChange={(event) => setNewTask({ ...newTask, title: event.target.value })} placeholder="Task title" className="rounded-2xl border p-3 outline-none" />
                <select value={newTask.assignedTo} onChange={(event) => setNewTask({ ...newTask, assignedTo: event.target.value })} className="rounded-2xl border bg-white p-3 outline-none">
                  <option value="">Assign To</option>
                  {users.map((user) => (
                    <option key={user.id} value={user.name}>{user.name}</option>
                  ))}
                </select>
                <input type="date" value={newTask.targetDate} onChange={(event) => setNewTask({ ...newTask, targetDate: event.target.value })} className="rounded-2xl border p-3 outline-none" />
                <input value={newTask.behalfOf} onChange={(event) => setNewTask({ ...newTask, behalfOf: event.target.value })} placeholder="Behalf Of / Customer / Team" className="rounded-2xl border p-3 outline-none" />
                <select value={newTask.priority} onChange={(event) => setNewTask({ ...newTask, priority: event.target.value })} className="rounded-2xl border bg-white p-3 outline-none">
                  <option>Low</option>
                  <option>Medium</option>
                  <option>High</option>
                </select>
                <select multiple value={newTask.mentions} onChange={(event) => setNewTask({ ...newTask, mentions: Array.from(event.target.selectedOptions, (option) => option.value) })} className="min-h-[52px] rounded-2xl border bg-white p-3 outline-none">
                  {users.map((user) => (
                    <option key={user.id} value={user.name}>{user.name}</option>
                  ))}
                </select>
                <textarea value={newTask.description} onChange={(event) => setNewTask({ ...newTask, description: event.target.value })} placeholder="Task details / instructions" className="rounded-2xl border p-3 outline-none md:col-span-2" />
                <Button type="submit" className="rounded-2xl">Create Task</Button>
              </form>
              {taskMessage && <p className="mt-3 rounded-xl bg-blue-50 p-3 text-xs font-semibold text-blue-700">{taskMessage}</p>}
              <p className="mt-3 text-xs text-slate-500">Task creator ko apna assigned task visible rahega. Assigned person ko task complete/update karne ka option milega. Leader ko sabka pending, in-progress aur history data dikhega.</p>
            </CardContent>
          </Card>
        )}

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="rounded-3xl border-0 shadow-sm lg:col-span-2">
            <CardContent className="p-0">
              <div className="flex items-center justify-between border-b p-5">
                <div>
                  <h2 className="text-xl font-bold">Active Task List</h2>
                  <p className="text-sm text-slate-500">Pending and in-progress tasks stay active. Completed tasks move to history.</p>
                </div>
                <span className={`rounded-full px-3 py-1 text-sm font-semibold ${isLeader ? "bg-emerald-50 text-emerald-700" : "bg-blue-50 text-blue-700"}`}>{isLeader ? "Admin / Leader View" : "My View"}</span>
              </div>

              <div className="block space-y-3 p-4 md:hidden">
                {visibleTasks.length === 0 ? (
                  <div className="rounded-2xl bg-slate-50 p-5 text-center text-sm text-slate-500">No active tasks found.</div>
                ) : (
                  visibleTasks.map((task) => (
                    <div key={task.id} className="rounded-2xl border bg-white p-4 shadow-sm">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-xs font-bold text-blue-700">{task.id}</p>
                          <h3 className="mt-1 font-bold text-slate-900">{task.title}</h3>
                          <p className="mt-1 text-xs text-slate-500">{task.description || "No details added."}</p>
                        </div>
                        <span className={`shrink-0 rounded-full px-3 py-1 text-xs font-bold ${priorityClass(task.priority)}`}>{task.priority}</span>
                      </div>

                      <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
                        <div className="rounded-xl bg-slate-50 p-3">
                          <p className="text-slate-500">Assigned By</p>
                          <p className="font-semibold text-slate-900">{task.assignedBy}</p>
                        </div>
                        <div className="rounded-xl bg-slate-50 p-3">
                          <p className="text-slate-500">Assigned To</p>
                          <p className="font-semibold text-slate-900">{task.assignedTo}</p>
                        </div>
                        <div className="rounded-xl bg-slate-50 p-3">
                          <p className="text-slate-500">Target</p>
                          <p className="font-semibold text-slate-900">{dateLabel(task.targetDate)}</p>
                        </div>
                        <div className="rounded-xl bg-slate-50 p-3">
                          <p className="text-slate-500">Behalf Of</p>
                          <p className="font-semibold text-slate-900">{task.behalfOf}</p>
                        </div>
                      </div>

                      {Array.isArray(task.mentions) && task.mentions.length > 0 && (
                        <p className="mt-3 text-xs text-slate-500"><b>Mentions:</b> {task.mentions.join(", ")}</p>
                      )}

                      <div className="mt-4">
                        <select disabled={!canUpdateTaskStatus(task, currentUser)} value={task.status} onChange={(event) => updateTaskStatus(task.id, event.target.value)} className={`w-full rounded-2xl border px-3 py-3 text-sm font-bold outline-none ${statusClass(task.status)} ${!canUpdateTaskStatus(task, currentUser) ? "cursor-not-allowed opacity-60" : ""}`}>
                          <option>Pending</option>
                          <option>In Progress</option>
                          <option>Completed</option>
                        </select>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="hidden overflow-x-auto md:block">
                <table className="w-full min-w-[980px] text-left text-sm">
                  <thead className="bg-slate-100 text-slate-600">
                    <tr>
                      <th className="p-4">Task ID</th>
                      <th className="p-4">Task Description</th>
                      <th className="p-4">Assigned By</th>
                      <th className="p-4">Assigned To</th>
                      <th className="p-4">Behalf Of</th>
                      <th className="p-4">Mentions</th>
                      <th className="p-4">Target</th>
                      <th className="p-4">Priority</th>
                      <th className="p-4">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {visibleTasks.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="p-8 text-center text-slate-500">No active tasks found.</td>
                      </tr>
                    ) : (
                      visibleTasks.map((task) => (
                        <tr key={task.id} className="border-b last:border-0 hover:bg-slate-50">
                          <td className="p-4 font-semibold text-blue-700">{task.id}</td>
                          <td className="p-4"><div className="font-semibold">{task.title}</div><div className="text-xs text-slate-500">{task.description}</div></td>
                          <td className="p-4">{task.assignedBy}</td>
                          <td className="p-4 font-semibold">{task.assignedTo}</td>
                          <td className="p-4">{task.behalfOf}</td>
                          <td className="p-4 text-xs text-slate-500">{Array.isArray(task.mentions) && task.mentions.length ? task.mentions.join(", ") : "-"}</td>
                          <td className="p-4">{dateLabel(task.targetDate)}</td>
                          <td className="p-4"><span className={`rounded-full px-3 py-1 text-xs font-bold ${priorityClass(task.priority)}`}>{task.priority}</span></td>
                          <td className="p-4">
                            <select disabled={!canUpdateTaskStatus(task, currentUser)} value={task.status} onChange={(event) => updateTaskStatus(task.id, event.target.value)} className={`rounded-full border px-3 py-1 text-xs font-bold outline-none ${statusClass(task.status)} ${!canUpdateTaskStatus(task, currentUser) ? "cursor-not-allowed opacity-60" : ""}`}>
                              <option>Pending</option>
                              <option>In Progress</option>
                              <option>Completed</option>
                            </select>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-6">
            {isLeader && (
              <Card className="rounded-3xl border-0 bg-emerald-50 shadow-sm">
                <CardContent className="p-5">
                  <div className="mb-4 flex items-center gap-2">
                    <UserPlus className="h-5 w-5" />
                    <h2 className="text-xl font-bold">Add New Member</h2>
                  </div>
                  <form onSubmit={addNewMember} className="space-y-3">
                    <input value={newMember.name} onChange={(event) => setNewMember({ ...newMember, name: event.target.value })} placeholder="Member Name" className="w-full rounded-2xl border p-3 outline-none" />
                    <input value={newMember.loginId} onChange={(event) => setNewMember({ ...newMember, loginId: event.target.value })} placeholder="Login ID" className="w-full rounded-2xl border p-3 outline-none" />
                    <input value={newMember.officeId} onChange={(event) => setNewMember({ ...newMember, officeId: event.target.value })} placeholder="Office Email ID" className="w-full rounded-2xl border p-3 outline-none" />
                    <input value={newMember.password} onChange={(event) => setNewMember({ ...newMember, password: event.target.value })} placeholder="Password" className="w-full rounded-2xl border p-3 outline-none" />
                    <Button type="submit" className="w-full rounded-2xl">Add Member</Button>
                  </form>
                  <p className="mt-3 text-xs text-emerald-700">Leader-only control: team members cannot see or use this form.</p>
                </CardContent>
              </Card>
            )}

            <Card className="rounded-3xl border-0 shadow-sm">
              <CardContent className="p-5">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <KeyRound className="h-5 w-5" />
                    <div>
                      <h2 className="text-lg font-bold">Security</h2>
                      <p className="text-xs text-slate-500">Change your own password only.</p>
                    </div>
                  </div>
                  <Button type="button" onClick={() => setShowChangePassword(!showChangePassword)} variant="outline" className="rounded-2xl bg-white">
                    {showChangePassword ? "Close" : "Change"}
                  </Button>
                </div>

                {showChangePassword && (
                  <form onSubmit={changeOwnPassword} className="mt-4 space-y-3">
                    <input type="password" value={passwordForm.oldPassword} onChange={(event) => setPasswordForm({ ...passwordForm, oldPassword: event.target.value })} placeholder="Old password" className="w-full rounded-2xl border p-3 outline-none" />
                    <input type="password" value={passwordForm.newPassword} onChange={(event) => setPasswordForm({ ...passwordForm, newPassword: event.target.value })} placeholder="New password" className="w-full rounded-2xl border p-3 outline-none" />
                    <input type="password" value={passwordForm.confirmPassword} onChange={(event) => setPasswordForm({ ...passwordForm, confirmPassword: event.target.value })} placeholder="Confirm new password" className="w-full rounded-2xl border p-3 outline-none" />
                    <Button type="submit" className="w-full rounded-2xl">Update Password</Button>
                  </form>
                )}

                {passwordMessage && <p className="mt-3 rounded-xl bg-slate-50 p-3 text-xs font-semibold text-slate-700">{passwordMessage}</p>}
              </CardContent>
            </Card>

            {isLeader && (
              <Card className="rounded-3xl border-0 shadow-sm">
                <CardContent className="p-5">
                  <div className="mb-4 flex items-center gap-2"><Users className="h-5 w-5" /><h2 className="text-xl font-bold">Team Overview</h2></div>
                  <div className="space-y-3">
                    {users.map((user) => {
                      const userTaskCount = visibleTasks.filter((task) => task.assignedTo === user.name).length;
                      return (
                        <div key={user.id} className="flex items-center justify-between rounded-2xl bg-slate-50 p-3">
                          <div>
                            <p className="font-semibold">{user.name}</p>
                            <p className="text-xs text-slate-500">{user.role}</p>
                          </div>
                          <span className="rounded-full bg-white px-3 py-1 text-xs font-bold text-slate-700">{userTaskCount} Tasks</span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {isLeader && (
              <Card className="rounded-3xl border-0 shadow-sm">
                <CardContent className="p-5">
                  <div className="mb-4 flex items-center gap-2"><UserCheck className="h-5 w-5" /><h2 className="text-xl font-bold">Behalf-wise Team Tasks</h2></div>
                  {behalfSummary.length === 0 ? <p className="text-sm text-slate-500">No tasks found.</p> : (
                    <div className="space-y-3">
                      {behalfSummary.map(([name, count]) => (
                        <div key={name}>
                          <div className="mb-1 flex justify-between text-sm"><span className="font-semibold">{name}</span><span>{count}</span></div>
                          <div className="h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-slate-800" style={{ width: `${Math.max(12, (count / Math.max(1, summary.total)) * 100)}%` }} /></div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            <Card className="rounded-3xl border-0 bg-slate-900 text-white shadow-sm">
              <CardContent className="p-5">
                <div className="mb-3 flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-amber-300" /><h2 className="text-lg font-bold">{isLeader ? "Leader Rule" : "Member Rule"}</h2></div>
                <p className="text-sm text-slate-200">
                  {isLeader
                    ? "Leader can add members, assign tasks, monitor all team work, export reports, complete tasks, and check history."
                    : "Team member can create tasks, see assigned/created/mentioned tasks, update assigned task status, change own password, and check own history."}
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <Card className="rounded-3xl border-0 shadow-sm">
          <CardContent className="p-0">
            <div className="flex items-center justify-between border-b p-5">
              <div><h2 className="text-xl font-bold">Task History</h2><p className="text-sm text-slate-500">Completed tasks are stored here for 30 days and then automatically removed from history.</p></div>
              <span className="rounded-full bg-slate-100 px-3 py-1 text-sm font-semibold text-slate-700">{visibleHistoryTasks.length} Records</span>
            </div>
            <div className="block space-y-3 p-4 md:hidden">
              {visibleHistoryTasks.length === 0 ? (
                <div className="rounded-2xl bg-slate-50 p-5 text-center text-sm text-slate-500">No history records found.</div>
              ) : (
                visibleHistoryTasks.map((task) => {
                  const autoDeleteDate = new Date(task.completedDate);
                  autoDeleteDate.setDate(autoDeleteDate.getDate() + 30);
                  return (
                    <div key={task.id} className="rounded-2xl border bg-white p-4 shadow-sm">
                      <p className="text-xs font-bold text-blue-700">{task.id}</p>
                      <h3 className="mt-1 font-bold text-slate-900">{task.title}</h3>
                      <p className="mt-1 text-xs text-slate-500">{task.description || "No details added."}</p>
                      <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
                        <div className="rounded-xl bg-slate-50 p-3">
                          <p className="text-slate-500">Assigned To</p>
                          <p className="font-semibold text-slate-900">{task.assignedTo}</p>
                        </div>
                        <div className="rounded-xl bg-slate-50 p-3">
                          <p className="text-slate-500">Completed</p>
                          <p className="font-semibold text-slate-900">{dateLabel(task.completedDate)}</p>
                        </div>
                        <div className="col-span-2 rounded-xl bg-slate-50 p-3">
                          <p className="text-slate-500">History Auto Delete</p>
                          <p className="font-semibold text-slate-900">{dateLabel(autoDeleteDate.toISOString().slice(0, 10))}</p>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="hidden overflow-x-auto md:block">
              <table className="w-full min-w-[980px] text-left text-sm">
                <thead className="bg-slate-100 text-slate-600">
                  <tr>
                    <th className="p-4">Task ID</th>
                    <th className="p-4">Task Description</th>
                    <th className="p-4">Assigned By</th>
                    <th className="p-4">Assigned To</th>
                    <th className="p-4">Behalf Of</th>
                    <th className="p-4">Completed Date</th>
                    <th className="p-4">History Auto Delete</th>
                    <th className="p-4">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {visibleHistoryTasks.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-500">No history records found.</td>
                    </tr>
                  ) : (
                    visibleHistoryTasks.map((task) => {
                      const autoDeleteDate = new Date(task.completedDate);
                      autoDeleteDate.setDate(autoDeleteDate.getDate() + 30);
                      return (
                        <tr key={task.id} className="border-b last:border-0 hover:bg-slate-50">
                          <td className="p-4 font-semibold text-blue-700">{task.id}</td>
                          <td className="p-4"><div className="font-semibold">{task.title}</div><div className="text-xs text-slate-500">{task.description}</div></td>
                          <td className="p-4">{task.assignedBy}</td>
                          <td className="p-4 font-semibold">{task.assignedTo}</td>
                          <td className="p-4">{task.behalfOf}</td>
                          <td className="p-4">{dateLabel(task.completedDate)}</td>
                          <td className="p-4">{dateLabel(autoDeleteDate.toISOString().slice(0, 10))}</td>
                          <td className="p-4"><span className={`rounded-full border px-3 py-1 text-xs font-bold ${statusClass(task.status)}`}>{task.status}</span></td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
