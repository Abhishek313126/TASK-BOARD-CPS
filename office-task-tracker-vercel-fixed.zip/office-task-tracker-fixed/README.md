# Office Task Tracker

Mobile-friendly internal task tracking dashboard built with React + Vite + Tailwind.

## Run locally

```bash
npm install
npm run dev
```

## Build check

```bash
npm run build
```

## Deploy on Vercel

1. Upload this project to GitHub.
2. In Vercel, click **Add New > Project**.
3. Import your GitHub repo.
4. Use these settings:
   - Framework Preset: **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`
5. Click **Deploy**.

## Demo Login

Leader:
- Login ID: `pradeep.accounts`
- Password: `Pradeep@123`

Team members:
- `abhishek.accounts` / `Abhishek@123`
- `mounika.accounts` / `Mounika@123`
- `swathiv.accounts` / `SwathiV@123`
- `mswathi.accounts` / `MSwathi@123`
- `shashi.accounts` / `Shashi@123`
- `modiji.accounts` / `Modiji@123`
- `ashutosh.accounts` / `Ashutosh@123`

## Notes

This is a frontend demo. Data is stored in browser state, so refresh resets task data. For real office use, connect Supabase or Firebase for authentication, task database, email OTP, and scheduled 30-day history cleanup.
